from django.db import models
from django.contrib.auth.models import User
# Create your models here.
class profile(models.Model):
    user=models.OneToOneField(User,on_delete=models.CASCADE)
    auth_token=models.CharField(max_length=100)
    is_verified=models.BooleanField(default=False)
    created_at=models.DateTimeField(auto_now_add=True)

class postjob(models.Model):
    catchoice=[
        ('remote','remote'),
        ('hybri','hybrid'),

    ]
    jobtype=[
        ('part time','part time'),
        ('full time','full time'),
    ]
    exp=[
        ('0-1','0-1'),
        ('1-2','1-2'),
        ('2-3','2-3'),
        ('3-4','3-4'),
        ('4-5','4-5'),
    ]
    cname=models.CharField(max_length=30)
    cemail=models.EmailField()
    ctitle=models.CharField(max_length=50)
    ctype=models.CharField(max_length=30,choices=catchoice)
    jtype=models.CharField(max_length=30,choices=jobtype)
    cexp=models.CharField(max_length=30,choices=exp)
class regumodel(models.Model):
    qua = [
        ('B.Tech', 'B.Tech'),
        ('Diploma', 'Diploma'),
        ('Plus Two', 'Plus Two'),
        ('SSLC', 'SSLC'),

    ]
    uname=models.CharField(max_length=25)
    email=models.EmailField()
    phone = models.IntegerField()
    qualification=models.CharField(max_length=30,choices=qua)
    password=models.CharField(max_length=20)
class applymodel(models.Model):
    compnm=models.CharField(max_length=50)
    jobtitle=models.CharField(max_length=50)
    empname=models.CharField(max_length=50)
    empemail=models.EmailField()
    empph=models.IntegerField()
    exp=models.CharField(max_length=100)
    pdf=models.FileField()
