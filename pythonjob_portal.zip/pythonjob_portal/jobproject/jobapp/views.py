from django.shortcuts import render,redirect
from django.contrib import messages
from django.contrib.auth.models import User
import uuid
from .models import *
from django.core.mail import send_mail
from jobproject.settings import EMAIL_HOST_USER
from django.http import HttpResponse
from django.contrib.auth import authenticate
from .forms import*

# Create your views here.
def index(request):
    return render(request,'index.html')
def index2(request):
    return render(request,'index2.html')

def regis(request):
    if request.method=='POST':
        username=request.POST.get('usname')
        email=request.POST.get('email')
        password = request.POST.get('password')
        if User.objects.filter(username=username).first():
            messages.success(request,'username already taken')
            return redirect(regis)
        if User.objects.filter(email=email).first():

            messages.success("email already exist")
            return redirect(regis)
        user_obj=User(username=username,email=email)
        user_obj.set_password(password)
        user_obj.save()
        auth_token=str(uuid.uuid4())
        profile_obj = profile.objects.create(user=user_obj, auth_token=auth_token)
        profile_obj.save()
        send_mail_regis(email, auth_token)
        return redirect(tok)
    return render(request, 'reg.html')
def send_mail_regis(email , token):
    subject="your account has been verified"
    message=f"paste the link to verify your account http://127.0.0.1:8000/jobapp/verify/{token}"
    email_from=EMAIL_HOST_USER
    recipient=[email]
    send_mail(subject,message,email_from,recipient)
def tok(request):
    return render(request,'success.html')
def verify(request,auth_token):
    profile_obj=profile.objects.filter(auth_token=auth_token).first()
    if profile_obj:
        if profile_obj.is_verified:
            messages.success(request,'your account is verified')
            return redirect(login)
        profile_obj.is_verified=True
        profile_obj.save()
        messages.success(request,'your account has been verified ')
        return redirect(login)
    else:
        return redirect(error)

def login(request):
    if request.method=='POST':
        username=request.POST.get('username')
        password=request.POST.get('password')
        email=request.POST.get('email')

        user_obj=User.objects.filter(username=username).first()
        if user_obj is None:
            messages.success(request,'user not found')
            return redirect(login)
        profile_obj = profile.objects.filter(user=user_obj).first()
        if not profile_obj.is_verified:
            messages.success(request, 'profile not verified check your mail')
            return redirect(login)
        user = authenticate(username=username, password=password,email=email)
        if user is None:
            messages.success(request, 'wrong password or username')
            return redirect(login)

        obj=profile.objects.filter(user=user)
        return render(request,"prf.html",{'obj':obj})
    return render(request, 'login.html')
def error(request):
    return render(request,'error.html')
def post(request):
    if request.method=='POST':
        a=postjobform(request.POST)
        if a.is_valid():
            cname=a.cleaned_data['cname']
            cemail=a.cleaned_data['cemail']
            ctitle= a.cleaned_data['ctitle']
            ctype= a.cleaned_data['ctype']
            jtype= a.cleaned_data['jtype']
            cexp= a.cleaned_data['cexp']
            b=postjob(cname=cname,cemail=cemail,ctitle=ctitle,ctype=ctype,jtype=jtype,cexp=cexp)
            b.save()
            return HttpResponse("job posted")
        else:
            return HttpResponse("error")
    return render(request,'post.html')


def regcompany(request):
    us=User.objects.all()

    li=[]
    email=[]
    for i in us:
        nm=i.username
        li.append(nm)
        em=i.email
        email.append(em)
    # mylist=zip(li,email)
    # print(li)
    # print(email)
    li.pop(8)
    email.pop(8)
    mylist=zip(li,email)
    return render(request,'reg_company.html',{'mylist':mylist})
def mailsend(request,id):
    a=User.objects.get(id=id)
    u=a.username
    b=a.email
    print(u)
    print(b)
    return render(request,'mailsend.html', {'u':u ,'b':b})


def regu(request):
    if request.method=='POST':
        a=reguform(request.POST)
        if a.is_valid():
            us=a.cleaned_data['uname']
            em=a.cleaned_data['email']
            ph=a.cleaned_data['phone']
            qu=a.cleaned_data['qualification']
            ps=a.cleaned_data['password']
            cps=a.cleaned_data['password1']
            if ps==cps:
                b=regumodel(uname=us,email=em,phone=ph,qualification=qu,password=ps)
                b.save()
                return HttpResponse("registration success")
            else:
                return HttpResponse("password incorrect")
        else:
            return HttpResponse("registration failed")
    return render(request,'reglog.html')
def loginu(request):
    if request.method=='POST':
        a=loguform(request.POST)
        if a.is_valid():
            em=a.cleaned_data['email']
            passw=a.cleaned_data['password']
            b=regumodel.objects.all()
            for i in b:
                if em==i.email and passw==i.password:
                    us = i.uname
                    em = i.email
                    ph = i.phone
                    qu = i.qualification
                    id=i.id
                    print(us)
                    print(em)
                    return render(request,'empprof.html',{'us':us,'em':em,'ph':ph,'qu':qu,'id':id})
            else:
                return HttpResponse("login failed")


    return render(request,'loginu.html')
def edit(request,id):
    user=regumodel.objects.get(id=id)
    if request.method=='POST':
        user.uname=request.POST.get('uname')
        user.email=request.POST.get('email')
        user.phone=request.POST.get('phone')
        user.qualification=request.POST.get('qualification')

        user.save()
        return redirect(loginu)
    return render(request,'editemp.html',{'user':user})


def viewjob(request,id):
    b1=regumodel.objects.filter(id=id)
    for i in b1:
        x1=i.uname
        x2=i.id

    a1=postjob.objects.all()
    l1=[]
    l2=[]
    l3=[]
    for i in a1:
        b1=i.ctitle
        l1.append(b1)
        b2=i.cname
        l2.append(b2)
        b3=i.id
        l3.append(b3)
    list=zip(l1,l2,l3)
    return render(request,'viewjob.html',{"list":list,"x1":x1,"x2":x2})


def viewmore(request,id,pk):
    a1=postjob.objects.get(id=id)
    b1=regumodel.objects.get(id=pk)
    return render(request,'viewmore.html',{"a1":a1,"b1":b1})

def applynow(request,id,pk):
    a1 = postjob.objects.get(id=id)
    b1 = regumodel.objects.get(id=pk)
    if request.method=='POST':
        a=applyform(request.POST,request.FILES)
        if a.is_valid():
            compnm1 = a.cleaned_data['compnm']
            jobtitle1 = a.cleaned_data['jobtitle']
            empname1 = a.cleaned_data['empname']
            empemail1 = a.cleaned_data['empemail']
            empph1 = a.cleaned_data['empph']
            exp1 = a.cleaned_data['exp']
            pdf1=a.cleaned_data['pdf']
            b=applymodel(compnm=compnm1,jobtitle=jobtitle1,empname=empname1,empemail=empemail1,empph=empph1,exp=exp1,pdf=pdf1)
            b.save()
            return HttpResponse("Job application successful")
        else:
            return HttpResponse("error")
    return render(request, 'apply.html', {"a1": a1, "b1": b1})