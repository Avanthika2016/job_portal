from django import forms
class postjobform(forms.Form):
    cname=forms.CharField(max_length=30)
    cemail=forms.EmailField()
    ctitle=forms.CharField(max_length=50)
    ctype=forms.CharField(max_length=30)
    jtype=forms.CharField(max_length=30)
    cexp=forms.CharField(max_length=30)

class reguform(forms.Form):
    uname=forms.CharField(max_length=25)
    email=forms.EmailField()
    qualification=forms.CharField(max_length=50)
    phone=forms.IntegerField()
    password=forms.CharField(max_length=20)
    password1=forms.CharField(max_length=20)
class loguform(forms.Form):
    email = forms.EmailField()
    password = forms.CharField(max_length=20)

class applyform(forms.Form):
    compnm = forms.CharField(max_length=50)
    jobtitle = forms.CharField(max_length=50)
    empname = forms.CharField(max_length=50)
    empemail = forms.EmailField()
    empph = forms.IntegerField()
    exp = forms.CharField(max_length=100)
    pdf = forms.FileField()
